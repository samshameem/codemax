<?php
namespace api\Exceptions;

/**
 * Class apiSDKException
 *
 * @package api
 */
class apiSDKException extends \Exception
{
}
